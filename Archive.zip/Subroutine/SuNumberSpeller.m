//
//  SuNumberSpeller.m
//  Subroutine
//
//  Created by Shimin Lu on 11/03/2013.
//  Copyright (c) 2013 shimin lu. All rights reserved.
//

#import "SuNumberSpeller.h"
@interface SuNumberSpeller ()
{
    NSArray*_tensDigits;
    NSArray*_units;
    NSArray*_largeUnits;
    
}

@end


@implementation SuNumberSpeller

-(id)init{

    self= [super init];
    if (self) {
        _units = @[@"one",
                   @"two",
                   @"three",
                   @"four",
                   @"five",
                   @"six",
                   @"seven",
                   @"eight",
                   @"nine",
                   @"ten",
                   @"eleven",
                   @"twelve",
                   @"thirteen",
                   @"fourteen",
                   @"fifteen",
                   @"fifteen",
                   @"seventeen",
                   @"eighteen",
                   @"nineteen"
                   ];
        
        _tensDigits = @[@"twenty",
                        @"thirty",
                        @"forty",
                        @"fifty",
                        @"sixty",
                        @"seventy",
                        @"eighty",
                        @"ninety"
                        ];
        
        _largeUnits = @[@"hundred",
                        @"thousand",
                        @"million",
                        @"billion",
                        @"trillion",
                        @"quadrillion"];
    }
    return self;
}

-(NSString*)spellFormatNumber:(NSNumber*)number{
    
    long long num = [number longLongValue];
    NSMutableString* spellResult = [[NSMutableString alloc]init];
    int i = 0;
    while (num) {
        int remainder = num%1000;     
        NSString *str =[self spellThreeDigits:remainder];
        
        if (i) {
            NSString*lstr = [NSString stringWithFormat:@"%@ %@ ",str,_largeUnits[i]];
            [spellResult insertString:lstr atIndex:0];
        }else {
            [spellResult appendString:str];
        }
        
        num /=1000;
        i++;       
    }
    
    NSLog(@"spelling result: %@",spellResult);
    return spellResult;

}

-(NSString*)spellThreeDigits:(NSUInteger)num{

    int u=0,t=0,h=0;
    NSMutableString *result = [[NSMutableString alloc]init];
    
    //split out
    u = num%10;
    t = ((num-u)%100)/10;
    h = ((num-t-u)%1000)/100;
    
    
    if (h>0) {
        [result appendFormat:@"%@ %@ ",_units[h-1],_largeUnits[0]];
    }
    if (t>0) {
        if (t>1) {
            [result appendFormat:@"%@",_tensDigits[t-2]];
            
            if (u>0) {
                [result appendFormat:@"-%@",_units[u-1]];
            }            
        }else {
            int tens = num%100;
            [result appendString:_units[tens-1]];
        }
    }else {  [result appendString:_units[u-1]];  }
 
 
    return result;
}


@end
