//
//  SuAppDelegate.h
//  Subroutine
//
//  Created by shimin lu on 21/02/2013.
//  Copyright (c) 2013 shimin lu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SuAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
