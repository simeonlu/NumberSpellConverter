//
//  SuViewController.m
//  Subroutine
//
//  Created by shimin lu on 21/02/2013.
//  Copyright (c) 2013 shimin lu. All rights reserved.
//

#import "SuViewController.h"
#import "SuNumberSpeller.h"


@interface SuViewController () <UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *inputField;
@property (weak, nonatomic) IBOutlet UILabel *resultLabel;

@end

@implementation SuViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	 
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
   
}
- (IBAction)ConvertAction:(UIButton *)sender {
    
    [self.view.window endEditing:YES];
    
}

#pragma mark - helpers

-(NSString*)convertToSpellString:(NSNumber*)num{

    // custom API
    SuNumberSpeller*speller =[[SuNumberSpeller alloc]init];
    NSString  *spelling = [speller spellFormatNumber:num];
    
    /* build-in Apple API     
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc]init];
    [formatter setNumberStyle:NSNumberFormatterSpellOutStyle];
    NSString  *spelling = [formatter stringFromNumber:num];
    
     */
    
    assert(speller);
    return spelling;
}


-(NSString*)insertCharactersToString:(NSString*)string{
    
    NSMutableString *result = [NSMutableString stringWithString:string];
    NSRange range = [string rangeOfString:@"HUNDRED" options:NSBackwardsSearch];
    
    if (range.location!=NSNotFound) {
        [result insertString:@" AND " atIndex:range.location + @"HUNDRED".length];
        range = [string rangeOfString:@"THOUSAND" options:NSBackwardsSearch];
        if (range.location!=NSNotFound) {
            [result insertString:@" AND " atIndex:range.location + @"THOUSAND".length];
            range = [string rangeOfString:@"MILLION" options:NSBackwardsSearch];
            if (range.location!=NSNotFound) {
                [result insertString:@" AND " atIndex:range.location + @"MILLION".length];
            }
        }
    }

    return result;
}

#pragma mark - Text Field delegate
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if (range.location>15)    return NO;
    else                    return YES;
}

-(void)textFieldDidEndEditing:(UITextField *)textField{

    if (textField.text.length>0) {
       
        NSArray *parts = [[NSString stringWithFormat:@"%.02f",[textField.text doubleValue]] componentsSeparatedByString:@"."];
       
        // integer part
        
        NSString*convertedIntStr = nil;
        NSDecimalNumber *numInt = [NSDecimalNumber decimalNumberWithString:parts[0]];
        
        long long s = [numInt longLongValue];
        if (s>0) {
            NSString *currency =  s>1? @" DOLLARS": @" DOLLAR";            
            convertedIntStr = [[[self convertToSpellString:numInt] stringByAppendingString:currency ]uppercaseString];
            convertedIntStr = [self insertCharactersToString:convertedIntStr];
        }
        
        
        //fraction part
        
        if (parts.count>1) {
            NSString *convertedDeciStr =nil;
            NSDecimalNumber *numDeci = [NSDecimalNumber decimalNumberWithString:parts[1]];
            int c = [numDeci integerValue];
           
            if (c>0) {
                NSString *cent =  c>1? @" CENTS": @" CENT";                
                convertedDeciStr = [[[self convertToSpellString:numDeci] stringByAppendingString:cent] uppercaseString];
                if (convertedIntStr) {
                    self.resultLabel.text = [NSString stringWithFormat:@"%@ AND %@",convertedIntStr,convertedDeciStr];
                }else  self.resultLabel.text = convertedDeciStr;
                
                return;
            }
        }
            
        self.resultLabel.text = convertedIntStr;
        NSLog(@"%@\nresult:\n%@",textField.text, convertedIntStr);
    }else{
        self.resultLabel.text = nil;
    }
}

-(BOOL)textFieldShouldClear:(UITextField *)textField{

    self.resultLabel.text = nil;
    return YES;
}








@end
