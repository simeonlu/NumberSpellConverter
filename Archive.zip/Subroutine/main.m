//
//  main.m
//  Subroutine
//
//  Created by shimin lu on 21/02/2013.
//  Copyright (c) 2013 shimin lu. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SuAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SuAppDelegate class]));
    }
}
